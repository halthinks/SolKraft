---
name: solforge-workflow-writing-draft
description: Produce the selected document package with evidence, visuals, citations, review gates, and exports.
---

<!-- solkraft-doc-sync: contract-aware-v1 | semantic-exact-match | 2026-10 -->

# Draft the document package

Use the [native execution contract](../solforge/references/native-execution.md) once per task.

Establish the audience, purpose, required format and length, and the acceptance criteria before writing. Inventory the supplied source material and map it to the claims the document must make; where a required claim has no inspected source, flag it as a gap to fill or a scope question rather than drafting around it. Confirm which sections, visuals, citations, and exports the request actually requires, and scale the package to that instead of filling a maximal template.

Outline before drafting: give each section a job and the evidence that supports it. Write claims only where a source was inspected, keeping facts, inferences, and recommendations visibly distinct; a confident sentence with no traceable source is an unsupported claim, not prose polish. Include a visual only when it carries information the text cannot — a chart that restates no data is decoration, and decoration that implies evidence is worse than none. Cite what was actually read, and keep each citation attached to the specific claim it supports rather than collected as an ornamental bibliography.

Review in passes: structure (the document answers the stated purpose for the stated audience), evidence (every material claim traces to an inspected source or is labeled an assumption), and mechanics (format, length, terminology, consistency). Verify exports by opening the exported artifact — a successful export command is not proof that figures, tables, and references survived. Do not pad length to appear thorough, and do not present an outline or partial draft as the finished package.

Return the deliverable in the requested format, state which claims rest on inspected sources versus open assumptions, and name any gap the sources could not close. Use [report production](../solforge-run-report-write/SKILL.md) when the task needs the full production method — plan execution, review gates, and export handling — beyond this drafting pass.

<!-- BEGIN SOLKRAFT SKILL INTEGRATION -->
## SolKraft integration

- Selected by the contract-aware router; selection is advisory.
- Hardened routing rejects opaque or inadmissible capabilities.
- Contract metadata is evaluated before loading the full instruction body.
- Execution authority stays with the host.
- Validation evidence and limits: see the repository VALIDATION.md and docs/SEMANTIC_ROUTER_PROOF.md for the source-bound exact-match acceptance, retained original diagnostics, and rerun instructions. A selected route does not prove execution or perfect matching.

<!-- END SOLKRAFT SKILL INTEGRATION -->
