---
name: solforge-workflow-consequential-publish
description: Carry out an explicitly authorized publish action for its exact target and verify the resulting effect.
---

<!-- solkraft-doc-sync: contract-aware-v1 | semantic-exact-match | 2026-10 -->

# Publish an authorized artifact

Use the [native execution contract](../solforge/references/native-execution.md) once per task.

Establish the explicit effect authorization before anything else. The request must name the publish action and its exact target: the specific artifact and version, the destination (registry, repository, channel, storefront, site), and the intended visibility or audience. Selection, an include-all route, or a plan that merely ends in "publish" grants no effect; if the action or target is inferred rather than stated, stop and obtain the authorization. Record what was authorized, for which target, and on what basis as part of the evidence.

Confirm the artifact to publish is exactly the one authorized: check its identity (path, version, checksum, build) against the reviewed deliverable rather than publishing whatever happens to be current. Determine reversibility and blast radius before acting — whether the destination supports delisting, retraction, or version rollback, how far the artifact propagates (indexing, caches, mirrors, subscriber notifications), and whether a mistaken publish is recoverable at all. Where the target supports it, use draft, staging, or dry-run modes to validate metadata, credentials, and permissions without creating the public effect.

Execute the authorized publish once, exactly as scoped: no broader visibility, no additional targets, no bundled side actions. Treat an ambiguous submission response as an uncertain state rather than a failure to retry — re-query the target before resubmitting, because a blind retry can double-publish. A queued, scheduled, or accepted-for-processing status is not publication.

Verify the effect at the target itself: retrieve or observe the published artifact as its audience would and confirm identity, version, and visibility match the authorization. An API success response without an observable artifact is weak evidence. Report the action and exact target, the authorization basis, the observed effect with its evidence, the rollback or retraction path if one exists, and any divergence from what was authorized. Use [report production](../solforge-report/SKILL.md) when the artifact to publish is itself a report still to be produced; generating it is a separate stage from publishing it.

<!-- BEGIN SOLKRAFT SKILL INTEGRATION -->
## SolKraft integration

- This procedure is selected by SolKraft's contract-aware router; selection does not authorize execution.
- Public routing defaults to hardened policy; opaque or contract-inadmissible capabilities fail closed.
- When `contract.yaml` exists, compact metadata is evaluated before this full instruction body is loaded.
- Runtime authority stays with the host; SolKraft keeps `execution_authorized: false`.
- See repository `VALIDATION.md` and `docs/SEMANTIC_ROUTER_PROOF.md` for current executed results, source identity, precision limits, and rerun instructions. Do not infer perfect matching or execution from a selected route.

<!-- END SOLKRAFT SKILL INTEGRATION -->
