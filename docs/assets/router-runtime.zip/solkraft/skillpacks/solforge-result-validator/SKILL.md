---
name: solforge-result-validator
description: "Check that a deliverable actually meets the requested outcome using inspected artifacts and observed behavior. Use before consequential completion claims."
---

<!-- solkraft-doc-sync: contract-aware-v1 | semantic-exact-match | 2026-10 -->

# Validate the requested result

Use the [native execution contract](../solforge/references/native-execution.md) once per task.

Translate the user's actual request into observable acceptance conditions. Include supplied constraints and required inputs; do not add a new product scope. Bind each material completion claim to the exact file, revision, artifact, environment, or output that was inspected.

Evaluate evidence at the level of the claim: source inspection establishes code presence; execution establishes observed behavior; integration requires exercising the relevant boundary. Local tests do not establish deployment, installation, physical performance, or production readiness. For a document, inspect its actual contents and supporting sources; for a visual deliverable, inspect the rendered result.

Look specifically for omitted requirements, stale evidence after edits, mocks standing in for required dependencies, inaccessible outputs, and tests that cannot distinguish success from the original defect. Reuse valid checks rather than repeat them for ceremony. Independence means challenging the proposed conclusion with evidence; it does not require spawning an agent.

If a gap is fixable within the authorized task, resolve it and repeat only the affected validation. Otherwise state the unmet condition and the evidence or external action needed. Report completion only to the extent demonstrated, with remaining limitations alongside the affected claim.

<!-- BEGIN SOLKRAFT SKILL INTEGRATION -->
## SolKraft integration

- This procedure is selected by SolKraft's contract-aware router; selection does not authorize execution.
- Public routing defaults to hardened policy; opaque or contract-inadmissible capabilities fail closed.
- When `contract.yaml` exists, compact metadata is evaluated before this full instruction body is loaded.
- Runtime authority stays with the host; SolKraft keeps `execution_authorized: false`.
- See repository `VALIDATION.md` and `docs/SEMANTIC_ROUTER_PROOF.md` for current executed results, source identity, precision limits, and rerun instructions. Do not infer perfect matching or execution from a selected route.

<!-- END SOLKRAFT SKILL INTEGRATION -->
