---
name: solforge-workflow-software-mobile-adaptation
description: Implement a honest mobile redesign with platform lifecycle, interaction, storage, permissions, packaging, and device verification.
---

<!-- solkraft-doc-sync: contract-aware-v1 | semantic-exact-match | 2026-10 -->

# Adapt software for mobile platforms

Use the [native execution contract](../solforge/references/native-execution.md) once per task.

Establish the target platforms and minimum OS versions, the source application being adapted, which features must survive the move, and the acceptance criteria for the mobile build. Inspect the existing codebase before choosing an approach: a shared-core port with a native shell, a cross-platform framework, or a platform-native rewrite are different commitments, and the decision should follow from dependencies, UI surface area, and team ownership rather than fashion.

Work through the platform realities in order. Lifecycle first: mobile apps are suspended, backgrounded, and killed without notice, so every screen must restore state and no work may assume a persistent process. Interaction next: replace pointer affordances with touch targets of adequate size, respect safe areas and system gestures, and handle orientation, keyboard occlusion, and one-handed reach. Then storage and networking: use the platform's sanctioned directories, assume connectivity is intermittent and metered, and never write to paths that desktop code assumed were stable. Request permissions at first actual use with a clear rationale, and keep the app functional when any permission is denied.

Package per platform: signing identities, bundle identifiers, versioning, and store metadata are part of the deliverable, not afterthoughts. Produce an installable artifact through the real toolchain. Verify on physical devices across the OS range you claim to support. Exercise cold start, backgrounding and resume mid-task, permission denial, offline transitions, low storage, and rotation. An emulator-only pass is not device evidence; a screenshot of the home screen is not lifecycle evidence; and "works in the shared simulator" says nothing about the release-signed artifact. Record device, OS version, build identifier, and the exact scenario exercised for each claim.

Report what was adapted, the verified behaviors with their device evidence, known limits such as untested OS versions or deferred features, and how to reproduce the build. Use [cross build](../solforge-cross-build/SKILL.md) when the packaging step needs full toolchain configuration and reproducibility procedure beyond what this workflow covers.

<!-- BEGIN SOLKRAFT SKILL INTEGRATION -->
## SolKraft integration

- Selected by the contract-aware router; selection is advisory.
- Hardened routing rejects opaque or inadmissible capabilities.
- Contract metadata is evaluated before loading the full instruction body.
- Execution authority stays with the host.
- Validation evidence and limits: see the repository VALIDATION.md and docs/SEMANTIC_ROUTER_PROOF.md for the source-bound exact-match acceptance, retained original diagnostics, and rerun instructions. A selected route does not prove execution or perfect matching.

<!-- END SOLKRAFT SKILL INTEGRATION -->
