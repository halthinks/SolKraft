---
name: solforge-workflow-codebase
description: "Investigate a repository to answer how a feature works, where behavior lives, or what a change depends on. Use for focused code understanding."
---

<!-- solkraft-doc-sync: contract-aware-v1 | semantic-exact-match | 2026-10 -->

# Investigate a codebase

Use the [native execution contract](../solforge/references/native-execution.md) once per task.

Pin the question to answer, the exact repository and revision, and the scope the requester cares about — a feature, a behavior, or a proposed change boundary. Establish what an acceptable answer looks like: file-level evidence, a dependency path, an architecture map, or a patch plan. Read the repository's own instructions before drawing conclusions, and note uncommitted changes before attributing behavior to a checkout.

Anchor the search at the user-visible surface — a route, command, public function, or error string — then trace inward through callers, implementation, state, and configuration to the owning boundary. Distinguish code that exists from code that is registered, called, reachable, and exercised; check feature flags, generated files, alternate implementations, and error paths when they could change the answer. Expand in breadth only when traced links require it: a focused question does not need an inventory of the whole repository.

Support every material claim with evidence at a concrete file, function, or revision. Search hits and directory names are leads, not findings — read the code before citing it. When explanations compete, name the discriminating observation and collect it; a small reproduction or an existing test resolves uncertainty that reading cannot. Inspection alone does not establish runtime behavior, and history explains why code changed, not what it does now. Do not present a plausible call chain as confirmed when a registration or wiring step was never checked.

Report the finding with its evidence chain, the relevant dependency path, and unresolved uncertainty. When the question feeds a requested change, carry the evidence forward as a scoped patch plan instead of starting the repair unasked. Use [repository investigation](../solforge-codebase/SKILL.md) when the tracing method itself needs deeper guidance.

<!-- BEGIN SOLKRAFT SKILL INTEGRATION -->
## SolKraft integration

- This procedure is selected by SolKraft's contract-aware router; selection does not authorize execution.
- Public routing defaults to hardened policy; opaque or contract-inadmissible capabilities fail closed.
- When `contract.yaml` exists, compact metadata is evaluated before this full instruction body is loaded.
- Runtime authority stays with the host; SolKraft keeps `execution_authorized: false`.
- See repository `VALIDATION.md` and `docs/SEMANTIC_ROUTER_PROOF.md` for current executed results, source identity, precision limits, and rerun instructions. Do not infer perfect matching or execution from a selected route.

<!-- END SOLKRAFT SKILL INTEGRATION -->
